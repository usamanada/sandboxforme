Public Class DeclarativeProg
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents DirtyChecker1 As BillysDirtyChecker.DirtyChecker
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.RadioButton1 = New System.Windows.Forms.RadioButton
        Me.RadioButton2 = New System.Windows.Forms.RadioButton
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.DirtyChecker1 = New BillysDirtyChecker.DirtyChecker(Me.components)
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.TextBox1, True)
        Me.TextBox1.Location = New System.Drawing.Point(56, 40)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = "TextBox1"
        '
        'TextBox2
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.TextBox2, True)
        Me.TextBox2.Location = New System.Drawing.Point(56, 88)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.TabIndex = 1
        Me.TextBox2.Text = "TextBox2"
        '
        'CheckBox1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.CheckBox1, True)
        Me.CheckBox1.Location = New System.Drawing.Point(232, 64)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.TabIndex = 2
        Me.CheckBox1.Text = "CheckBox1"
        '
        'RadioButton1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.RadioButton1, True)
        Me.RadioButton1.Location = New System.Drawing.Point(240, 96)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(136, 24)
        Me.RadioButton1.TabIndex = 3
        Me.RadioButton1.Text = "RadioButton1"
        '
        'RadioButton2
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.RadioButton2, True)
        Me.RadioButton2.Location = New System.Drawing.Point(240, 120)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(136, 24)
        Me.RadioButton2.TabIndex = 4
        Me.RadioButton2.Text = "RadioButton2"
        '
        'ComboBox1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.ComboBox1, True)
        Me.ComboBox1.Items.AddRange(New Object() {"Red", "B;lue", "Greem"})
        Me.ComboBox1.Location = New System.Drawing.Point(48, 128)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 26)
        Me.ComboBox1.TabIndex = 5
        Me.ComboBox1.Text = "ComboBox1"
        '
        'ListBox1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.ListBox1, True)
        Me.ListBox1.ItemHeight = 18
        Me.ListBox1.Items.AddRange(New Object() {"Red", "Blue", "Green", "Yellow"})
        Me.ListBox1.Location = New System.Drawing.Point(48, 192)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(120, 94)
        Me.ListBox1.TabIndex = 6
        '
        'Button1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Button1, False)
        Me.Button1.Enabled = False
        Me.Button1.Location = New System.Drawing.Point(304, 248)
        Me.Button1.Name = "Button1"
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "Save"
        '
        'DirtyChecker1
        '
        Me.DirtyChecker1.LastDirty = False
        '
        'TextBox3
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.TextBox3, False)
        Me.TextBox3.Location = New System.Drawing.Point(328, 0)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(96, 24)
        Me.TextBox3.TabIndex = 8
        Me.TextBox3.Text = "TextBox3"
        '
        'Button2
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Button2, False)
        Me.Button2.Location = New System.Drawing.Point(240, 0)
        Me.Button2.Name = "Button2"
        Me.Button2.TabIndex = 9
        Me.Button2.Text = "Start"
        '
        'Button3
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Button3, False)
        Me.Button3.Location = New System.Drawing.Point(304, 32)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(104, 23)
        Me.Button3.TabIndex = 10
        Me.Button3.Text = "External Dirty"
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'DeclarativeProg
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(7, 17)
        Me.ClientSize = New System.Drawing.Size(424, 330)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.RadioButton2)
        Me.Controls.Add(Me.RadioButton1)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me, False)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "DeclarativeProg"
        Me.Text = "DeclarativeProg"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.DirtyChecker1.Start()

    End Sub

    Private Sub DirtyChecker1_DirtyChanged(ByVal sender As Object, ByVal e As BillysDirtyChecker.DirtyChangedEventArgs) Handles DirtyChecker1.DirtyChanged
        If e.Dirty Then
            Button1.Enabled = True
        Else
            Button1.Enabled = False

        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Timer1.Enabled = True

    End Sub

    Private externalDirty As Boolean = False
    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        externalDirty = Not externalDirty
        Me.DirtyChecker1.ExternalDirty = externalDirty


    End Sub
End Class
