Public Class Form3
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents btnStart As System.Windows.Forms.Button
    Friend WithEvents DirtyChecker1 As BillysDirtyChecker.DirtyChecker
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.btnSave = New System.Windows.Forms.Button
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.RadioButton2 = New System.Windows.Forms.RadioButton
        Me.RadioButton1 = New System.Windows.Forms.RadioButton
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.btnStart = New System.Windows.Forms.Button
        Me.DirtyChecker1 = New BillysDirtyChecker.DirtyChecker(Me.components)
        Me.CheckBox2 = New System.Windows.Forms.CheckBox
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnSave
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.btnSave, False)
        Me.btnSave.Enabled = False
        Me.btnSave.Location = New System.Drawing.Point(200, 280)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.TabIndex = 0
        Me.btnSave.Text = "Save"
        '
        'TextBox1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.TextBox1, True)
        Me.TextBox1.Location = New System.Drawing.Point(56, 32)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.Text = "TextBox1"
        '
        'TextBox2
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.TextBox2, True)
        Me.TextBox2.Location = New System.Drawing.Point(56, 64)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.TabIndex = 2
        Me.TextBox2.Text = "TextBox2"
        '
        'CheckBox1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.CheckBox1, True)
        Me.CheckBox1.Location = New System.Drawing.Point(56, 96)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.TabIndex = 3
        Me.CheckBox1.Text = "CheckBox1"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RadioButton2)
        Me.GroupBox1.Controls.Add(Me.RadioButton1)
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.GroupBox1, False)
        Me.GroupBox1.Location = New System.Drawing.Point(56, 128)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'RadioButton2
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.RadioButton2, True)
        Me.RadioButton2.Location = New System.Drawing.Point(16, 64)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(136, 24)
        Me.RadioButton2.TabIndex = 1
        Me.RadioButton2.Text = "RadioButton2"
        '
        'RadioButton1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.RadioButton1, True)
        Me.RadioButton1.Location = New System.Drawing.Point(16, 32)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(128, 24)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.Text = "RadioButton1"
        '
        'ComboBox1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.ComboBox1, True)
        Me.ComboBox1.Items.AddRange(New Object() {"Red", "Blue", "Green", "Yellow", "Purple"})
        Me.ComboBox1.Location = New System.Drawing.Point(56, 240)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 24)
        Me.ComboBox1.TabIndex = 5
        Me.ComboBox1.Text = "ComboBox1"
        '
        'btnStart
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.btnStart, False)
        Me.btnStart.Location = New System.Drawing.Point(192, 16)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.TabIndex = 6
        Me.btnStart.Text = "Start"
        '
        'DirtyChecker1
        '
        Me.DirtyChecker1.LastDirty = False
        '
        'CheckBox2
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.CheckBox2, False)
        Me.CheckBox2.Location = New System.Drawing.Point(200, 72)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(136, 24)
        Me.CheckBox2.TabIndex = 7
        Me.CheckBox2.Text = "My own dirty stuff"
        '
        'Form3
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 16)
        Me.ClientSize = New System.Drawing.Size(344, 322)
        Me.Controls.Add(Me.CheckBox2)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.btnSave)
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me, False)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Form3"
        Me.Text = "Form3"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        Me.DirtyChecker1.Start()

    End Sub

    Private Sub DirtyChecker1_DirtyChanged(ByVal sender As Object, ByVal e As BillysDirtyChecker.DirtyChangedEventArgs) Handles DirtyChecker1.DirtyChanged
        If e.Dirty Then
            btnSave.Enabled = True
        Else
            btnSave.Enabled = False

        End If
    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        Me.DirtyChecker1.ExternalDirty = CheckBox2.Checked

    End Sub
End Class
