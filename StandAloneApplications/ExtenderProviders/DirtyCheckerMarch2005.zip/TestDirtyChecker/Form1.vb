Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents DirtyChecker1 As BillysDirtyChecker.DirtyChecker
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents MonthCalendar1 As System.Windows.Forms.MonthCalendar
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents chkButton14 As System.Windows.Forms.CheckBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.DirtyChecker1 = New BillysDirtyChecker.DirtyChecker(Me.components)
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.RadioButton1 = New System.Windows.Forms.RadioButton
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker
        Me.MonthCalendar1 = New System.Windows.Forms.MonthCalendar
        Me.Button1 = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.Button2 = New System.Windows.Forms.Button
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.Button3 = New System.Windows.Forms.Button
        Me.ListBox2 = New System.Windows.Forms.ListBox
        Me.Button4 = New System.Windows.Forms.Button
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.ComboBox2 = New System.Windows.Forms.ComboBox
        Me.Button5 = New System.Windows.Forms.Button
        Me.Button6 = New System.Windows.Forms.Button
        Me.ComboBox3 = New System.Windows.Forms.ComboBox
        Me.Button7 = New System.Windows.Forms.Button
        Me.Button8 = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.Button9 = New System.Windows.Forms.Button
        Me.CheckBox2 = New System.Windows.Forms.CheckBox
        Me.Button10 = New System.Windows.Forms.Button
        Me.Button11 = New System.Windows.Forms.Button
        Me.Button12 = New System.Windows.Forms.Button
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox
        Me.Button13 = New System.Windows.Forms.Button
        Me.Button14 = New System.Windows.Forms.Button
        Me.chkButton14 = New System.Windows.Forms.CheckBox
        Me.SuspendLayout()
        '
        'DirtyChecker1
        '
        Me.DirtyChecker1.LastDirty = False
        '
        'TextBox1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.TextBox1, True)
        Me.TextBox1.Location = New System.Drawing.Point(47, 21)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(83, 20)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = "TextBox1"
        '
        'TextBox2
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.TextBox2, True)
        Me.TextBox2.Location = New System.Drawing.Point(47, 55)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(83, 20)
        Me.TextBox2.TabIndex = 1
        Me.TextBox2.Text = "TextBox2"
        '
        'CheckBox1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.CheckBox1, True)
        Me.CheckBox1.Location = New System.Drawing.Point(33, 90)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(87, 21)
        Me.CheckBox1.TabIndex = 2
        Me.CheckBox1.Text = "CheckBox1"
        '
        'RadioButton1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.RadioButton1, True)
        Me.RadioButton1.Location = New System.Drawing.Point(33, 132)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(87, 21)
        Me.RadioButton1.TabIndex = 3
        Me.RadioButton1.Text = "RadioButton1"
        '
        'DateTimePicker1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.DateTimePicker1, True)
        Me.DateTimePicker1.Location = New System.Drawing.Point(20, 166)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(167, 20)
        Me.DateTimePicker1.TabIndex = 4
        '
        'MonthCalendar1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.MonthCalendar1, True)
        Me.MonthCalendar1.Location = New System.Drawing.Point(13, 194)
        Me.MonthCalendar1.Name = "MonthCalendar1"
        Me.MonthCalendar1.TabIndex = 5
        '
        'Button1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Button1, False)
        Me.Button1.Location = New System.Drawing.Point(200, 14)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(62, 20)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Start"
        '
        'Label1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Label1, False)
        Me.Label1.Location = New System.Drawing.Point(293, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(84, 20)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Label1"
        '
        'Button2
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Button2, False)
        Me.Button2.Location = New System.Drawing.Point(120, 132)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(62, 20)
        Me.Button2.TabIndex = 8
        Me.Button2.Text = "Reset"
        '
        'ListBox1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.ListBox1, True)
        Me.ListBox1.Items.AddRange(New Object() {"Red", "Blue", "Green", "Yellow", "Black", "Brown", "Purple"})
        Me.ListBox1.Location = New System.Drawing.Point(248, 296)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(100, 82)
        Me.ListBox1.TabIndex = 9
        '
        'Button3
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Button3, False)
        Me.Button3.Location = New System.Drawing.Point(272, 272)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(62, 20)
        Me.Button3.TabIndex = 10
        Me.Button3.Text = "Reset"
        '
        'ListBox2
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.ListBox2, True)
        Me.ListBox2.Items.AddRange(New Object() {"Red", "Blue", "Green", "Black", "Brown", "Yellow", "Purple"})
        Me.ListBox2.Location = New System.Drawing.Point(376, 296)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple
        Me.ListBox2.Size = New System.Drawing.Size(100, 82)
        Me.ListBox2.TabIndex = 11
        '
        'Button4
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Button4, False)
        Me.Button4.Location = New System.Drawing.Point(392, 272)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(63, 20)
        Me.Button4.TabIndex = 12
        Me.Button4.Text = "Reset"
        '
        'ComboBox1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.ComboBox1, True)
        Me.ComboBox1.Items.AddRange(New Object() {"Red", "Blue", "Green", "Yellow", "Pink"})
        Me.ComboBox1.Location = New System.Drawing.Point(240, 416)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(101, 21)
        Me.ComboBox1.TabIndex = 13
        Me.ComboBox1.Text = "ComboBox1"
        '
        'ComboBox2
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.ComboBox2, True)
        Me.ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox2.Items.AddRange(New Object() {"Red", "Blue", "Green", "Yellow", "Black", "Purple"})
        Me.ComboBox2.Location = New System.Drawing.Point(352, 416)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(100, 21)
        Me.ComboBox2.TabIndex = 14
        '
        'Button5
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Button5, False)
        Me.Button5.Location = New System.Drawing.Point(264, 440)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(62, 20)
        Me.Button5.TabIndex = 15
        Me.Button5.Text = "Reset"
        '
        'Button6
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Button6, False)
        Me.Button6.Location = New System.Drawing.Point(368, 440)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(62, 20)
        Me.Button6.TabIndex = 16
        Me.Button6.Text = "Reset"
        '
        'ComboBox3
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.ComboBox3, True)
        Me.ComboBox3.Location = New System.Drawing.Point(33, 381)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(101, 21)
        Me.ComboBox3.TabIndex = 17
        Me.ComboBox3.Text = "ComboBox3"
        '
        'Button7
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Button7, False)
        Me.Button7.Location = New System.Drawing.Point(47, 402)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(62, 20)
        Me.Button7.TabIndex = 18
        Me.Button7.Text = "Button7"
        '
        'Button8
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Button8, False)
        Me.Button8.Location = New System.Drawing.Point(296, 64)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(62, 20)
        Me.Button8.TabIndex = 19
        Me.Button8.Text = "Lowest"
        '
        'Label2
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Label2, False)
        Me.Label2.Location = New System.Drawing.Point(376, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(83, 20)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Label2"
        '
        'Button9
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Button9, False)
        Me.Button9.Location = New System.Drawing.Point(200, 42)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(62, 20)
        Me.Button9.TabIndex = 21
        Me.Button9.Text = "Cancel"
        '
        'CheckBox2
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.CheckBox2, False)
        Me.CheckBox2.Location = New System.Drawing.Point(136, 88)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(96, 20)
        Me.CheckBox2.TabIndex = 22
        Me.CheckBox2.Text = "External Dirty"
        '
        'Button10
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Button10, True)
        Me.Button10.Location = New System.Drawing.Point(48, 440)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(62, 20)
        Me.Button10.TabIndex = 23
        Me.Button10.Text = "1"
        '
        'Button11
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Button11, False)
        Me.Button11.Location = New System.Drawing.Point(120, 440)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(33, 20)
        Me.Button11.TabIndex = 24
        Me.Button11.Text = "to 2"
        '
        'Button12
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Button12, False)
        Me.Button12.Location = New System.Drawing.Point(160, 440)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(63, 20)
        Me.Button12.TabIndex = 25
        Me.Button12.Text = "back to 1"
        '
        'RichTextBox1
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.RichTextBox1, True)
        Me.RichTextBox1.Location = New System.Drawing.Point(240, 104)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(224, 136)
        Me.RichTextBox1.TabIndex = 26
        Me.RichTextBox1.Text = "RichTextBox1"
        '
        'Button13
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Button13, False)
        Me.Button13.Location = New System.Drawing.Point(312, 240)
        Me.Button13.Name = "Button13"
        Me.Button13.TabIndex = 27
        Me.Button13.Text = "Set bold"
        '
        'Button14
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.Button14, True)
        Me.Button14.Location = New System.Drawing.Point(504, 32)
        Me.Button14.Name = "Button14"
        Me.Button14.TabIndex = 28
        Me.Button14.Text = "Button14"
        '
        'chkButton14
        '
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me.chkButton14, False)
        Me.chkButton14.Location = New System.Drawing.Point(496, 64)
        Me.chkButton14.Name = "chkButton14"
        Me.chkButton14.TabIndex = 29
        Me.chkButton14.Text = "Make it dirty"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(592, 466)
        Me.Controls.Add(Me.chkButton14)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.CheckBox2)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.ComboBox3)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.MonthCalendar1)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.RadioButton1)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.DirtyChecker1.SetDirtyCheckingEnabled(Me, False)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.DirtyChecker1.Start()

    End Sub

    Private Sub DirtyChecker1_DirtyChanged(ByVal sender As Object, ByVal e As BillysDirtyChecker.DirtyChangedEventArgs) Handles DirtyChecker1.DirtyChanged
        Label1.Text = e.Dirty.ToString

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        RadioButton1.Checked = False

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        ListBox1.ClearSelected()

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        ListBox2.ClearSelected()

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        ComboBox1.SelectedIndex = -1
        ComboBox1.Text = ""

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        ComboBox2.SelectedIndex = -1

    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        ComboBox2.SelectedIndex = -1

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim ds As New DataSet
        ds.ReadXml("..\ListBoxData.xml")
        ComboBox3.DataSource = ds.Tables(0)
        ComboBox3.ValueMember = "CustomerID"
        ComboBox3.DisplayMember = "CustomerName"

        Dim x As New MyCustomDirtyChecker(Me)
        Me.DirtyChecker1.CustomIsDirtyContainer = x

    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        If Me.DirtyChecker1.FirstDirtyControl Is Nothing Then
            Label2.Text = "Nothing"
        Else
            Label2.Text = Me.DirtyChecker1.FirstDirtyControl.Name

        End If
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        Me.DirtyChecker1.Cancel()

    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        Me.DirtyChecker1.ExternalDirty = CheckBox2.Checked

    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        Button10.Text = "2"

    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        Button10.Text = "1"

    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        MsgBox("button 10 clicked")

    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        RichTextBox1.SelectionFont = New Font(Me.Font, FontStyle.Bold)

    End Sub

    Private Class MyCustomDirtyChecker
        Implements BillysDirtyChecker.iCustomIsDirtyContainer

        Public Function ControlSupported(ByVal ctrl As System.Windows.Forms.Control) As Boolean Implements BillysDirtyChecker.iCustomIsDirtyContainer.ControlSupported
            If ctrl.Name.ToUpper = "BUTTON14" Then
                Return True
            Else
                Return False

            End If
        End Function

        Public Function CustomIsDirty(ByVal ctrl As System.Windows.Forms.Control) As Boolean Implements BillysDirtyChecker.iCustomIsDirtyContainer.CustomIsDirty
            Select Case ctrl.Name.ToUpper

                Case "Button14".ToUpper
                    Return m_frm.chkButton14.Checked

                Case Else
                    Return False
            End Select
        End Function

        Dim m_frm As Form1
        Public Sub New(ByVal frm As Form1)
            m_frm = frm

        End Sub
    End Class

    Private Sub chkButton14_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkButton14.CheckedChanged
        Me.DirtyChecker1.CheckForDirtyChange(Button14)
    End Sub
End Class
