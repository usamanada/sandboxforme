Option Strict On
Imports System.Windows.Forms
Imports System.ComponentModel

'**************************************************
'* DirtyChecker and related classes
'*
'* Rewritten for VSLive San Francisco 2005
'**************************************************

' This class furnishes the event args for the
' DirtyChanged event. It needs to return the dirty state.
Public Class DirtyChangedEventArgs
    Inherits EventArgs

    Private m_blnDirty As Boolean
    Public Property Dirty() As Boolean
        Get
            Return m_blnDirty
        End Get
        Set(ByVal Value As Boolean)
            m_blnDirty = Value
        End Set
    End Property
End Class

' This is not used in this demo example, but I will use it in a future version.
Public Interface iCustomIsDirtyContainer
    Function CustomIsDirty(ByVal ctrl As Control) As Boolean
    Function ControlSupported(ByVal ctrl As Control) As Boolean

End Interface


' Class for stand-alone dirty checking.
' Implemented as an extender provider to allow it
' to be easy to specify which controls are part
' of the dirty checking. A control is enabled for
' dirty checking by making the DirtyCheckingEnabled 
' property True. 
<ProvideProperty("DirtyCheckingEnabled", GetType(Control))> _
Public Class DirtyChecker
    Inherits System.ComponentModel.Component
    Implements IExtenderProvider


#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        ' Need to initialize the collection of fields at startup
        colControlInformation = New Hashtable
    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container
    End Sub

#End Region

    ' This holds the provided property and the state data
    ' that allows dirty checking.
    Private colControlInformation As Hashtable

    ' This holds a custom dirty logic container. 
    ' Custom dirty logic is not implemented in this version, 
    ' but it will be included later.
    Shared m_objCustomIsDirty As iCustomIsDirtyContainer
    Public Shared Property CustomIsDirtyContainer() As iCustomIsDirtyContainer
        Get
            Return m_objCustomIsDirty
        End Get
        Set(ByVal Value As iCustomIsDirtyContainer)
            m_objCustomIsDirty = Value
        End Set
    End Property


    ' The ExternalDirty property gives consuming forms
    ' the capability to influence the overall dirty checking
    ' by indicating that they have an unmanaged field that is
    ' dirty. If set true, it will force a Dirty=true on the
    ' DirtyChecker as a whole. If set false, then the dirty value
    ' depends on whether any other fields are dirty.
    Dim m_blnExternalDirty As Boolean = False
    <Browsable(False)> _
    Public WriteOnly Property ExternalDirty() As Boolean
        Set(ByVal Value As Boolean)
            m_blnExternalDirty = Value
            CheckForDirtyChange(Me)

        End Set
    End Property


    ' This sub is called the first time something is added to the
    ' controls managed by this extender provider. It discovers the
    ' type of control, and hooks to any necessary events for that
    ' control type.
    Private Sub SetControlType(ByVal objProvidedProperties As ControlInformationHolder, ByVal ctl As Control)

        ' Bind to events for on-the-fly dirty checking. We attach to these
        ' events for all controls.
        AddHandler ctl.Click, AddressOf Me.CommonHandler
        AddHandler ctl.MouseUp, AddressOf Me.MouseUpHandler
        AddHandler ctl.KeyUp, AddressOf Me.KeyUpHandler


        ' Assume a type of Other, then change to correct type if we find it.
        objProvidedProperties.ControlType = ControlType.typeOther

        ' For specific control types, set the type and attach to any additional
        ' desirable events.
        If TypeOf ctl Is TextBox Then
            objProvidedProperties.ControlType = ControlType.typeTextbox
            Dim ctlTextBox As TextBox = CType(ctl, TextBox)
            AddHandler ctlTextBox.TextChanged, AddressOf Me.CommonHandler
            Exit Sub
        End If

        If TypeOf ctl Is RichTextBox Then
            objProvidedProperties.ControlType = ControlType.typeRichTextBox
            Dim ctlRichTextBox As RichTextBox = CType(ctl, RichTextBox)
            AddHandler ctlRichTextBox.TextChanged, AddressOf Me.CommonHandler
            Exit Sub
        End If

        If TypeOf ctl Is ListBox Then
            objProvidedProperties.ControlType = ControlType.typeListBox
            Dim ctlListControl As ListBox = CType(ctl, ListBox)
            AddHandler ctlListControl.TextChanged, AddressOf Me.CommonHandler
            AddHandler ctlListControl.SelectedValueChanged, AddressOf Me.CommonHandler
            Exit Sub
        End If

        If TypeOf ctl Is ComboBox Then
            objProvidedProperties.ControlType = ControlType.typeComboBox
            Dim ctlListControl As ComboBox = CType(ctl, ComboBox)
            AddHandler ctlListControl.TextChanged, AddressOf Me.CommonHandler
            AddHandler ctlListControl.SelectedValueChanged, AddressOf Me.CommonHandler
            Exit Sub
        End If

        If TypeOf ctl Is RadioButton Then
            objProvidedProperties.ControlType = ControlType.typeRadioButton
            Dim ctlRadioButton As RadioButton = CType(ctl, RadioButton)
            AddHandler ctlRadioButton.CheckedChanged, AddressOf Me.CommonHandler
            Exit Sub
        End If

        If TypeOf ctl Is CheckBox Then
            objProvidedProperties.ControlType = ControlType.typeCheckBox
            Dim ctlCheckBox As CheckBox = CType(ctl, CheckBox)
            AddHandler ctlCheckBox.CheckedChanged, AddressOf Me.CommonHandler
            Exit Sub
        End If

        If TypeOf ctl Is DateTimePicker Then
            objProvidedProperties.ControlType = ControlType.typeDatePicker
            Dim ctlDatePicker As DateTimePicker = CType(ctl, DateTimePicker)
            AddHandler ctlDatePicker.ValueChanged, AddressOf Me.CommonHandler
            Exit Sub
        End If

        If TypeOf ctl Is MonthCalendar Then
            objProvidedProperties.ControlType = ControlType.typeMonthCalendar
            Dim ctlMonthCalendar As MonthCalendar = CType(ctl, MonthCalendar)
            AddHandler ctlMonthCalendar.DateChanged, AddressOf Me.DateChangedHandler
            Exit Sub
        End If

        ' If get to here, didn't match any of the types, 
        ' so let's attach the TextChanged event. 
        AddHandler ctl.TextChanged, AddressOf Me.CommonHandler


    End Sub

    Public Sub Start()
        ' The consuming form calls this method when
        ' it is ready to start dirty checking. This is
        ' typically after the starting values have been
        ' filled into the affected controls. From this
        ' point onwards, dirty checking begins. If the
        ' IsDirty property is called before a Start is 
        ' issued, it will always return a False. 

        ' The inverse of this method is the Cancel method, 
        ' which stops dirty checking.

        mbExternalSuspended = False

        ' Loop through the fields, telling each field
        ' to fill up the data record with information from
        ' the control.

        Dim objField As ControlInformationHolder
        For Each obj As DictionaryEntry In colControlInformation
            objField = CType(obj.Value, ControlInformationHolder)

            Select Case objField.ControlType
                Case ControlType.typeCheckBox

                    Dim ctlCheckBox As CheckBox
                    ctlCheckBox = CType(obj.Key, CheckBox)
                    objField.BooleanValue = ctlCheckBox.Checked
                    objField.CheckStateValue = ctlCheckBox.CheckState

                Case ControlType.typeComboBox
                    Dim ctlComboBox As ComboBox
                    ctlComboBox = CType(obj.Key, ComboBox)

                    ' What we want to look at depends on how the 
                    ' combo box is being used. If it's a drop down only, 
                    ' then saving the currently selected index works best.
                    ' If info can be typed into it, however, we have to save the text.
                    If ctlComboBox.DropDownStyle = ComboBoxStyle.DropDownList Then

                        objField.IntegerValue = ctlComboBox.SelectedIndex
                    Else
                        objField.StringValue = ctlComboBox.Text
                    End If

                Case ControlType.typeDatePicker

                    Dim ctlDateTimePicker As DateTimePicker
                    ctlDateTimePicker = CType(obj.Key, DateTimePicker)
                    objField.BooleanValue = ctlDateTimePicker.Checked
                    objField.StringValue = ctlDateTimePicker.Value.ToLongDateString

                Case ControlType.typeListBox

                    Dim ctlListBox As ListBox
                    ctlListBox = CType(obj.Key, ListBox)

                    ' If a listbox is multi-select, then have to hang onto
                    ' all selected indices. So what we save depends on the
                    ' selection mode.
                    If ctlListBox.SelectionMode = SelectionMode.One Then
                        objField.IntegerValue = ctlListBox.SelectedIndex
                    Else

                        ' We have a function that stores a string
                        ' representation of the indices.
                        Dim sIndices As String
                        sIndices = ConstructIndices(ctlListBox)

                        objField.StringValue = sIndices

                    End If

                Case ControlType.typeMonthCalendar

                    Dim ctlMonthCalendar As MonthCalendar
                    ctlMonthCalendar = CType(obj.Key, MonthCalendar)

                    ' This control can have a date range selected, 
                    ' so we have to save both start and end point of the range.
                    objField.DateValue = ctlMonthCalendar.SelectionStart
                    objField.EndDateValue = ctlMonthCalendar.SelectionEnd

                Case ControlType.typeOther, ControlType.typeTextbox

                    Dim ctl As Control
                    ctl = CType(obj.Key, Control)

                    ' This will not work universally for all unknown controls.
                    ' However, it should work for many of them.
                    objField.StringValue = ctl.Text

                Case ControlType.typeRadioButton

                    Dim ctlRadioButton As RadioButton
                    ctlRadioButton = CType(obj.Key, RadioButton)
                    objField.BooleanValue = ctlRadioButton.Checked

                Case ControlType.typeRichTextBox
                    Dim ctlRichTextBox As RichTextBox
                    ctlRichTextBox = CType(obj.Key, RichTextBox)

                    ' The rich text box can also have formatting
                    ' changes, and these are exposed via the rtf property.
                    ' To speed things up, instead of storing the whole
                    ' text (plain and rtf versions), we'll just store
                    ' a hash code.
                    objField.IntegerValue = (ctlRichTextBox.Text & ctlRichTextBox.Rtf).GetHashCode

            End Select

        Next
        m_bDirtyCheckingStarted = True
        CheckForDirtyChange(Me)
    End Sub

    Private Function ConstructIndices(ByVal ctlListBox As ListBox) As String
        Dim sIndices As String
        For Each nIndex As Integer In ctlListBox.SelectedIndices
            sIndices &= nIndex.ToString & "~"
        Next
        Return sIndices
    End Function


    <Browsable(False)> _
    Public ReadOnly Property IsDirty() As Boolean
        ' Loop through the fields, checking each one for a
        ' dirty flag. If any field is dirty, then the 
        ' form is dirty. 

        Get

            ' If we've never begun checking, or if a Cancel has
            ' been issued without another Start, then it's false.
            If Not m_bDirtyCheckingStarted Then
                Return False
            End If

            Dim objField As ControlInformationHolder
            Dim iIndex As Integer

            ' Loop through the controls that are enabled for 
            ' dirty checking.
            For Each obj As DictionaryEntry In colControlInformation

                objField = CType(obj.Value, ControlInformationHolder)
                Dim ctl As Control = CType(obj.Key, Control)

                ' Depending on a property setting, we might be
                ' skipping invisible or disabled controls. 
                If Me.IncludeDisabledInvisibleControls OrElse (ctl.Enabled And ctl.Visible) Then
                    If FieldIsDirty(objField, ctl) Then
                        Return True
                    End If
                End If
            Next
            Return False

        End Get
    End Property

    Public Function ControlIsDirty(ByVal ctrl As Control) As Boolean

        ' This allows the consumer to check individual controls for
        ' a dirty state. If we are not working with the control, 
        ' then it's assumed clean. 
        Dim objField As ControlInformationHolder
        If colControlInformation.Contains(ctrl) Then
            objField = CType(colControlInformation(ctrl), ControlInformationHolder)

            Return FieldIsDirty(objField, ctrl)
        Else
            Return False
        End If

    End Function

    ' Find the dirty control with the lowest tab index.
    Public Function FirstDirtyControl() As Control

        Dim objField As ControlInformationHolder
        Dim ctlLowestDirtyControl As Control

        For Each obj As DictionaryEntry In colControlInformation

            objField = CType(obj.Value, ControlInformationHolder)
            Dim ctl As Control = CType(obj.Key, Control)

            If Me.IncludeDisabledInvisibleControls OrElse (ctl.Enabled And ctl.Visible) Then
                If FieldIsDirty(objField, ctl) Then
                    If ctlLowestDirtyControl Is Nothing Then
                        ctlLowestDirtyControl = ctl
                    Else
                        If ctlLowestDirtyControl.TabIndex > ctl.TabIndex Then
                            ctlLowestDirtyControl = ctl
                        End If
                    End If
                End If
            End If
        Next

        Return ctlLowestDirtyControl

    End Function

    ' This checks an individual field to see if it is dirty.
    ' Dirty checking varies with the type of control, but always
    ' involves checking what's currently in some property of the
    ' control against the saved value for that property.
    Private Function FieldIsDirty(ByVal objField As ControlInformationHolder, ByVal ctl As Control) As Boolean

        If Not m_bDirtyCheckingStarted Then
            Return False
        End If

        If Not objField.DirtyCheckingEnabled Then
            Return False

        End If


        Select Case objField.ControlType

            ' For each type, check against what we stored
            ' when the Start method was accessed.
            Case ControlType.typeCheckBox

                Dim ctlCheckBox As CheckBox
                ctlCheckBox = CType(ctl, CheckBox)

                If objField.CheckStateValue = ctlCheckBox.CheckState AndAlso objField.BooleanValue = ctlCheckBox.Checked Then
                    Return False
                Else
                    Return True
                End If


            Case ControlType.typeComboBox
                Dim ctlComboBox As ComboBox
                ctlComboBox = CType(ctl, ComboBox)
                If ctlComboBox.DropDownStyle = ComboBoxStyle.DropDownList Then

                    If objField.IntegerValue = ctlComboBox.SelectedIndex Then
                        Return False
                    Else
                        Return True
                    End If
                Else
                    If objField.StringValue = ctlComboBox.Text Then
                        Return False
                    Else
                        Return True

                    End If
                End If

            Case ControlType.typeDatePicker

                Dim ctlDateTimePicker As DateTimePicker
                ctlDateTimePicker = CType(ctl, DateTimePicker)
                If objField.BooleanValue = ctlDateTimePicker.Checked AndAlso objField.StringValue = ctlDateTimePicker.Value.ToLongDateString Then

                    Return False
                Else
                    Return True

                End If

            Case ControlType.typeListBox

                Dim ctlListBox As ListBox
                ctlListBox = CType(ctl, ListBox)
                If ctlListBox.SelectionMode = SelectionMode.One Then
                    If objField.IntegerValue = ctlListBox.SelectedIndex Then
                        Return False
                    Else
                        Return True
                    End If
                Else
                    Dim sIndices As String
                    sIndices = ConstructIndices(ctlListBox)

                    If objField.StringValue = sIndices Then
                        Return False
                    Else
                        Return True
                    End If

                End If

            Case ControlType.typeMonthCalendar

                Dim ctlMonthCalendar As MonthCalendar
                ctlMonthCalendar = CType(ctl, MonthCalendar)

                If objField.DateValue = ctlMonthCalendar.SelectionStart And objField.EndDateValue = ctlMonthCalendar.SelectionEnd Then
                    Return False
                Else
                    Return True

                End If


            Case ControlType.typeTextbox

                If objField.StringValue = ctl.Text Then
                    Return False
                Else
                    Return True
                End If

            Case ControlType.typeOther

                ' If they are not supplying a dirty checking
                ' component, then just check the text property.
                ' But if they have a custom checker, use it.
                If Me.CustomIsDirtyContainer Is Nothing Then
                    If objField.StringValue = ctl.Text Then
                        Return False
                    Else
                        Return True
                    End If
                Else
                    ' First see if the custom dirty checker supports
                    ' this control. 
                    If Me.CustomIsDirtyContainer.ControlSupported(ctl) Then
                        Return Me.CustomIsDirtyContainer.CustomIsDirty(ctl)
                    Else
                        If objField.StringValue = ctl.Text Then
                            Return False
                        Else
                            Return True
                        End If
                    End If
                End If

            Case ControlType.typeRichTextBox
                Dim ctlRichTextBox As RichTextBox
                ctlRichTextBox = CType(ctl, RichTextBox)
                If objField.IntegerValue = (ctlRichTextBox.Text & ctlRichTextBox.Rtf).GetHashCode Then
                    Return False
                Else
                    Return True
                End If


            Case ControlType.typeRadioButton

                Dim ctlRadioButton As RadioButton
                ctlRadioButton = CType(ctl, RadioButton)
                If objField.BooleanValue = ctlRadioButton.Checked Then
                    Return False
                Else
                    Return True
                End If
        End Select

    End Function

    ' Event handlers are needed for automated dirty checking.
    ' These events are hooked when a control is added to the collection.
    ' Each event checks for a change in dirty state and raises an event
    ' back in the form is such a change occurs.

    ' First define the event the handlers will raise.
    Public Event DirtyChanged(ByVal sender As Object, ByVal e As DirtyChangedEventArgs)

    ' Now the handlers. All of them point to the same underlying dirty checking routine.
    ' However, they take different eventargs, so we need several of them.
    Public Sub CommonHandler(ByVal sender As Object, ByVal e As EventArgs)
        ' This can be hooked to Click, TextChanged, and SelectedIndex changed events

        CheckForDirtyChange(sender)

    End Sub

    Public Sub MouseUpHandler(ByVal sender As Object, ByVal e As MouseEventArgs)
        CheckForDirtyChange(sender)

    End Sub

    Public Sub KeyUpHandler(ByVal sender As Object, ByVal e As KeyEventArgs)
        CheckForDirtyChange(sender)

    End Sub

    Public Sub DateChangedHandler(ByVal sender As Object, ByVal e As DateRangeEventArgs)
        ' This can be hooked to DateChanged changed events

        CheckForDirtyChange(sender)

    End Sub


    Private m_bSuspendDirtyChecking As Boolean = False

    ' This allows the form to force a dirty check, in the
    ' case where some event does not fire it automatically.
    ' This might be the case if some property value were
    ' changed in code without tripping any of the events for that
    ' control that cause automatic dirty checking. 
    Public Sub CheckForDirtyChange(ByVal sender As Object)
        If m_bSuspendDirtyChecking Or mbExternalSuspended Then
            Exit Sub
        End If

        Dim bCurrentDirty As Boolean = Me.IsDirty Or m_blnExternalDirty
        If bCurrentDirty <> Me.LastDirty Then
            Me.LastDirty = bCurrentDirty
            Dim e As New DirtyChangedEventArgs
            e.Dirty = bCurrentDirty
            RaiseEvent DirtyChanged(Me, e)

        End If
    End Sub

    ' This allows the component to keep its last dirty
    ' state, so that it knows when the state changes. 
    Dim mbLastDirty As Boolean = False
    <Browsable(False)> _
    Public Property LastDirty() As Boolean

        Get
            Return mbLastDirty
        End Get
        Set(ByVal Value As Boolean)
            mbLastDirty = Value
        End Set
    End Property

    ' This function is part of the iExtenderProvider interface, and
    ' tells what kind of controls the extender provider will 
    ' work with.
    Public Function CanExtend(ByVal target As Object) As Boolean Implements IExtenderProvider.CanExtend

        ' We only work with control (not with non-visual components)
        If Not TypeOf target Is Control Then
            Return False
        End If

        ' Don't even want to try to work with Treeviews, PictureBoxes, ListViews, or grids of any kind
        If (TypeOf target Is TreeView) Or _
            (TypeOf target Is PictureBox) Or _
            (TypeOf target Is ListView) Or _
            (InStr(target.GetType.ToString.ToUpper, "GRID")) <> 0 Then
            Return False
        End If

        ' We'll try to work for everything else
        Return True

        'If (TypeOf target Is TextBox) Or _
        '    (TypeOf target Is RichTextBox) Or _
        '    (TypeOf target Is Label) Or _
        '    (TypeOf target Is ComboBox) Or _
        '    (TypeOf target Is ListBox) Or _
        '    (TypeOf target Is Panel) Or _
        '    (TypeOf target Is DateTimePicker) Or _
        '    (TypeOf target Is NumericUpDown) Or _
        '    (TypeOf target Is CheckBox) Then

        '    Return True
        'End If
        Return False
    End Function


    ' Extender providers require Get and Set methods for extended properties.
    ' These are the Get and Set methods for the DirtyCheckingEnabled property.
    <DefaultValue(""), Description("Indicates whether this control participates in dirty checking for the DirtyChecker instance"), Category(" Billy's Dirty Checker")> _
    Public Function GetDirtyCheckingEnabled(ByVal ctrl As Control) As Boolean
        If colControlInformation(ctrl) Is Nothing Then
            Return False
        Else
            Dim obj As ControlInformationHolder
            obj = CType(colControlInformation(ctrl), ControlInformationHolder)
            Return obj.DirtyCheckingEnabled
        End If

    End Function

    Public Sub SetDirtyCheckingEnabled(ByVal ctrl As Control, ByVal value As Boolean)

        If Not value Then
            If colControlInformation.Contains(ctrl) Then
                Dim obj As New ControlInformationHolder
                obj = CType(colControlInformation(ctrl), ControlInformationHolder)
                If obj.DirtyCheckingEnabled Then
                    ' If previously involved in dirty checking, now need to detach events.
                    ' All handled controls are hooked to these events
                    RemoveHandler ctrl.Click, AddressOf Me.CommonHandler
                    RemoveHandler ctrl.MouseUp, AddressOf Me.MouseUpHandler
                    RemoveHandler ctrl.KeyUp, AddressOf Me.KeyUpHandler

                    Select Case obj.ControlType

                        Case ControlType.typeComboBox
                            Dim ctlListControl As ComboBox = CType(ctrl, ComboBox)
                            RemoveHandler ctlListControl.TextChanged, AddressOf Me.CommonHandler
                            RemoveHandler ctlListControl.SelectedValueChanged, AddressOf Me.CommonHandler

                        Case ControlType.typeDatePicker
                            Dim ctlDatePicker As DateTimePicker = CType(ctrl, DateTimePicker)
                            RemoveHandler ctlDatePicker.ValueChanged, AddressOf Me.CommonHandler

                        Case ControlType.typeListBox
                            Dim ctlListControl As ListBox = CType(ctrl, ListBox)
                            RemoveHandler ctlListControl.TextChanged, AddressOf Me.CommonHandler
                            RemoveHandler ctlListControl.SelectedValueChanged, AddressOf Me.CommonHandler

                        Case ControlType.typeMonthCalendar
                            Dim ctlMonthCalendar As MonthCalendar = CType(ctrl, MonthCalendar)
                            RemoveHandler ctlMonthCalendar.DateChanged, AddressOf Me.DateChangedHandler

                        Case ControlType.typeOther
                            ' no need to remove any more

                        Case ControlType.typeRadioButton
                            Dim ctlRadioButton As RadioButton = CType(ctrl, RadioButton)
                            RemoveHandler ctlRadioButton.CheckedChanged, AddressOf Me.CommonHandler

                        Case ControlType.typeCheckBox
                            Dim ctlCheckBox As CheckBox = CType(ctrl, CheckBox)
                            RemoveHandler ctlCheckBox.CheckedChanged, AddressOf Me.CommonHandler

                        Case ControlType.typeRichTextBox
                            Dim ctlTextBox As RichTextBox = CType(ctrl, RichTextBox)
                            RemoveHandler ctlTextBox.TextChanged, AddressOf Me.CommonHandler

                        Case ControlType.typeTextbox
                            Dim ctlTextBox As TextBox = CType(ctrl, TextBox)
                            RemoveHandler ctlTextBox.TextChanged, AddressOf Me.CommonHandler

                    End Select
                End If
                obj.DirtyCheckingEnabled = value
            Else
                ' never seen this control before
                Dim obj As New ControlInformationHolder
                obj.DirtyCheckingEnabled = value
                colControlInformation.Add(ctrl, obj)

            End If


        Else

            ' Here we are setting the control to be included 
            ' in dirty checking. Create a holder object for
            ' it and so other setup work for the control. 
            Dim obj As New ControlInformationHolder
            If colControlInformation(ctrl) Is Nothing Then
                obj.DirtyCheckingEnabled = value
                colControlInformation.Add(ctrl, obj)
            Else
                obj = CType(colControlInformation(ctrl), ControlInformationHolder)
                If obj.DirtyCheckingEnabled = value Then
                    Exit Sub
                End If
                obj.DirtyCheckingEnabled = value
            End If
            SetControlType(obj, ctrl)

        End If

    End Sub

    ' If this property is true, disabled and 
    ' invisible controls are skipped on the dirty check. 
    Dim mbIncludeDisabledInvisibleControls As Boolean = True
    <Description("Indicates whether the Dirty Checker includes disabled and invisible controls when checking dirty state"), DefaultValue(GetType(Boolean), "True")> _
    Public Property IncludeDisabledInvisibleControls() As Boolean
        Get
            Return mbIncludeDisabledInvisibleControls
        End Get
        Set(ByVal Value As Boolean)
            mbIncludeDisabledInvisibleControls = Value
        End Set
    End Property

    ' Allows manually forced dirty check, with
    ' events if change in state is found. 
    Public Sub RefreshIsDirty()
        CheckForDirtyChange(Me)

    End Sub

    Private m_bDirtyCheckingStarted As Boolean = False
    Public Sub Cancel()
        ' cancels dirty checking
        Me.m_bDirtyCheckingStarted = False
        CheckForDirtyChange(Me)

    End Sub

    ' Suspend and resume allow control over
    ' popping of DirtyChanged events. 
    Private mbExternalSuspended As Boolean = False
    Public Sub SuspendDirtyChecking()
        mbExternalSuspended = True
    End Sub

    Public Sub ResumeDirtyChecking()
        mbExternalSuspended = False
        RefreshIsDirty()
    End Sub

    ' This is the container for the provided property, 
    ' and also for the control state that needs to be
    ' stored to do dirty checking. 
    Private Class ControlInformationHolder

        Dim mbDirtyCheckingEnabled As Boolean
        Public Property DirtyCheckingEnabled() As Boolean
            Get
                Return mbDirtyCheckingEnabled
            End Get
            Set(ByVal Value As Boolean)
                mbDirtyCheckingEnabled = Value
            End Set
        End Property

        Public StringValue As String
        Public DateValue As Date
        Public EndDateValue As Date
        Public BooleanValue As Boolean
        Public IntegerValue As Integer
        Public CheckStateValue As CheckState
        Public ControlType As ControlType

    End Class

    Public Enum ControlType
        typeTextbox
        typeDatePicker
        typeMonthCalendar
        typeRadioButton
        typeCheckBox
        typeListBox
        typeComboBox
        typeRichTextBox
        typeOther
    End Enum

End Class

